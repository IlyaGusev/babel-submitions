cd /model
./translate.sh
