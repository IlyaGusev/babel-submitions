#! /usr/bin/env bash

/model/translate.sh corpus1.txt en
