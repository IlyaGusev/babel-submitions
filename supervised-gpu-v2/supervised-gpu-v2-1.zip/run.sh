#! /usr/bin/env bash

/model/translate.sh 13 10 3 400
